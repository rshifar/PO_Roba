﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace bankingManagementLIB
{
    public class Account
    {
        public int accNo { get; set; }
        public string  accName { get; set; }
        public string accType { get; set; }
        public int accBalance { get; set; }
        public string accStatus { get; set; }

        internal double widraw(int w_amount)
        {
            throw new NotImplementedException();
        }

        // public bool accIsAdmin { get; set; }

        SqlConnection con = new SqlConnection("server=DESKTOP-86SS27P\\ROBAINSTANCE; database=bankingManagementDB;integrated security = true");
        public List<Account> GetAllAccountInfo()
        {
            SqlCommand cmdAccountInfo = new SqlCommand("select * from AccountsInfo order by accNo", con);
            con.Open();
            SqlDataReader readAcc = cmdAccountInfo.ExecuteReader(); //this is point to output of query (not table)
                                                                    //then u will ask it to point to next record
            List<Account> accList = new List<Account>();

            while (readAcc.Read())
            {
                accList.Add(new Account()
                {
                    //  accNo = Convert.ToInt32(readAcc[0]),
                    accNo = (int)readAcc[0],
                    accName = readAcc[1].ToString(),
                    accType = readAcc[2].ToString(),
                    // accBalance = Convert.ToInt32(readAcc[3]),
                    accBalance = (int)readAcc[3],
                    // accStatus = readAcc[4].ToString()
                    //  accIsAdmin = (bool)readAcc[5]
                });

            }
            readAcc.Close();
            con.Close();
            return accList;
        }

        public bool checkAccountsExist(int p_accNo)
        {
            SqlCommand cmdCheck = new SqlCommand("select count(*) from AccountsInfo where accNo = @aNo", con);
            cmdCheck.Parameters.AddWithValue("@aNo", p_accNo);
            con.Open();
            int count = (int)cmdCheck.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }
         public string DisableAccount(int p_accNo)
         {
            SqlCommand cmdDisableAccounts = new SqlCommand("update  accountsInfo  set accStatus = @aStatus where accNo=@aNo", con);
            cmdDisableAccounts.Parameters.AddWithValue("@aNo", p_accNo);
            cmdDisableAccounts.Parameters.AddWithValue("@aStatus", "Disabled");
            con.Open();
            int updateResult = cmdDisableAccounts.ExecuteNonQuery(); 

            if (updateResult > 0) 
            {
                return "Accouns Disabled";
            }
            return "Account Not found";
            
         }
       
        public int GetAccountBalance(string p_accName)
        {
            SqlCommand cmdGetBalance = new SqlCommand("select accBalance from AccountsInfo left join userLogin on AccountsInfo.accName = userLogin.userName where userName = @userName", con);
            cmdGetBalance.Parameters.AddWithValue("@userName", p_accName);
           
            con.Open();
            SqlDataReader readRecord = cmdGetBalance.ExecuteReader();
            Account acc = new Account();
            
            if (readRecord.Read())
            {
                acc.accBalance = (int)readRecord[0];
            }
            else 
            {
                throw new Exception("Record Not Found");
            }
            readRecord.Close();
            con.Close();
            return acc.accBalance;
        } 
        
         public string AddAccount(int p_accNo, string p_accName, string p_accType, int p_accBalance)
            {
            SqlCommand cmdaddAccount = new SqlCommand("insert into AccountsInfo (accNo, accName, accType, accBalance) values (@aNo,@aName,@aType,@aBalance)", con);
            cmdaddAccount.Parameters.AddWithValue("@aNo",  p_accNo);
            cmdaddAccount.Parameters.AddWithValue("@aName", p_accName);
            cmdaddAccount.Parameters.AddWithValue("@aType", p_accType);
            cmdaddAccount.Parameters.AddWithValue("@aBalance", p_accBalance);
            
            
            try
            {
                con.Open();
                cmdaddAccount.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return "Account Added Successfully";
        }


        public string DeleteAccounts(int p_accNo)
        {
            SqlCommand cmdDeleteEmployee = new SqlCommand("delete from empInfo where empNo =@eNo", con);
            cmdDeleteEmployee.Parameters.AddWithValue("@eNo", p_accNo);
            con.Open();
            int recordAffected = cmdDeleteEmployee.ExecuteNonQuery();
            con.Close();
            if (recordAffected == 0)
            {
                return "Employee Not Found, and thus we could not delete";
            }
            return "Employee Deleted Successfully";
        }
        public string UpdateAccounts(Account p_accObj)
        {
            SqlCommand cmdUpdateAccounts = new SqlCommand("insert into accountsInfo values(@aNo, @aName, @aType, @aBalance, @aStatus" ,con);
            cmdUpdateAccounts.Parameters.AddWithValue("@aNo", p_accObj.accNo);
            cmdUpdateAccounts.Parameters.AddWithValue("@aName", p_accObj.accName);
            cmdUpdateAccounts.Parameters.AddWithValue("@aType", p_accObj.accType);
            cmdUpdateAccounts.Parameters.AddWithValue("@aBalance", p_accObj.accBalance);
           // cmdUpdateAccounts.Parameters.AddWithValue("@aStatus", p_accObj.accStatus);
            con.Open();
            int updateResult = cmdUpdateAccounts.ExecuteNonQuery();
            con.Close();
            if (updateResult > 0)
            {
                return "Accounts Updated Successfully !!";
            }
            return "Accounts Not Found";
        }
    }
}
