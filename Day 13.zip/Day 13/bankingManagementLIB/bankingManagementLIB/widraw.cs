﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace bankingManagementLIB
{
    public class widraw
    {
        public string Widraw(int p_fromAcc,  int p_amount, UserType p_userType)
        {
            SqlConnection con = new SqlConnection("server=DESKTOP-86SS27P\\ROBAINSTANCE;database=bankingManagementDB;integrated security=true");
            SqlCommand cmdfrom = new SqlCommand("update AccountsInfo set accBalance = accBalance - @amount where accNo = @fromAccount", con);
            cmdfrom.Parameters.AddWithValue("@amount", p_amount);
            cmdfrom.Parameters.AddWithValue("@fromAccount", p_fromAcc);

            SqlCommand cmdWidraw = new SqlCommand("insert into TransactionsInfo(calender,fromAccount,Amount,transferedBy) values(GETDATE(),@fromAccount,@amount,@uType)", con);
            cmdWidraw.Parameters.AddWithValue("@fromAccount", p_fromAcc);
            cmdWidraw.Parameters.AddWithValue("@amount", p_amount);

            if (p_userType == 0)
            {
                cmdWidraw.Parameters.AddWithValue("@uType", "Admin");
            }
            else
            {
                cmdWidraw.Parameters.AddWithValue("@uType", " Customer");
            }

            con.Open();

            cmdfrom.ExecuteNonQuery();
            cmdWidraw.ExecuteNonQuery();
            con.Close();

            return "Widraw Done";
        }
        


    }
}
