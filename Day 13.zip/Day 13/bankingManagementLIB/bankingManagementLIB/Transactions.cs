﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace bankingManagementLIB
{
    public class Transactions

    {
        //  #region my Variables (Account Transaction)
        public int fromAccount { get; set; }
        public int toAccount { get; set; }
        public int trNo { get; set; }
        public string transferedBy { get; set; }
        public string accDate { get; set; }
        public double accAmount { get; set; }

        SqlConnection con = new SqlConnection("server=DESKTOP-86SS27P\\ROBAINSTANCE;database=bankingManagementDB;integrated security=true");
        public string Transfer(int p_fromAcc, int p_toAccount, int p_amount, UserType p_userType)
        {
            SqlCommand cmdFrom = new SqlCommand("update AccountsInfo set accBalance = accBalance - @amount where accNo = @fromAccount", con);
            cmdFrom.Parameters.AddWithValue("@amount", p_amount);
            cmdFrom.Parameters.AddWithValue("@fromAccount", p_fromAcc);

            SqlCommand cmdTo = new SqlCommand("update AccountsInfo set accBalance = accBalance + @amount where accNo = @ToAccount", con);
            cmdTo.Parameters.AddWithValue("@amount", p_amount);
            cmdTo.Parameters.AddWithValue("@ToAccount", p_toAccount);

            SqlCommand cmdTransaction = new SqlCommand("insert into TransactionsInfo values(GETDATE(),@fromAccount,@ToAccount,@amount,@uType)", con);
            cmdTransaction.Parameters.AddWithValue("@fromAccount", p_fromAcc);
            cmdTransaction.Parameters.AddWithValue("@ToAccount", p_toAccount);
            cmdTransaction.Parameters.AddWithValue("@amount", p_amount);
            if (p_userType == 0)
            {
                cmdTransaction.Parameters.AddWithValue("@uType", "Admin");
            }
            else
            {
                cmdTransaction.Parameters.AddWithValue("@uType", "Customer");
            }

            con.Open();
            cmdFrom.ExecuteNonQuery();
            cmdTo.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Transfer Done";
        }

        public List<Transactions> GetTransactionsInfo(int p_fromAccount)
        {
            SqlCommand cmdTransactionsInfo = new SqlCommand("select TOP(10)* from TransactionsInfo where fromAccount = @froAccount", con);
            cmdTransactionsInfo.Parameters.AddWithValue("@froAccount" , p_fromAccount);
            con.Open();
            SqlDataReader readTrans = cmdTransactionsInfo.ExecuteReader();
            List<Transactions> tranList = new List<Transactions>();
            while (readTrans.Read())
            {
                //readTrans.Read();
                tranList.Add(new Transactions()
                {
                    trNo = (int)readTrans[0],
                    accDate = readTrans[1].ToString(),
                    fromAccount = (int)readTrans[2],
                    toAccount = (int)readTrans[3],
                    accAmount = (int)readTrans[4],
                    transferedBy = readTrans[5].ToString(),
                    
                    
                });
            }
            readTrans.Close();
            con.Close();
            return tranList;
        }
    }











}
    
 