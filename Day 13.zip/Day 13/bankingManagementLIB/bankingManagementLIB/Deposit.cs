﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace bankingManagementLIB
{
    public class Deposit
    {
        SqlConnection con = new SqlConnection("server=DESKTOP-86SS27P\\ROBAINSTANCE;database=bankingManagementDB;integrated security=true");
        public string GetDeposit(int p_toAccount,  int p_amount,UserType p_userType)
        {
            
            
            SqlCommand cmdTo = new SqlCommand("update AccountsInfo set accBalance = accBalance + @amount where accNo = @ToAccount", con);
            cmdTo.Parameters.AddWithValue("@amount", p_amount);
            cmdTo.Parameters.AddWithValue("@ToAccount", p_toAccount);
            SqlCommand cmdDeposit = new SqlCommand("insert into trInfo values(calender,toAccount,Amount,transfereBy)values(GETDATE(),@ToAccount,@amount,@uType)", con);
            cmdDeposit.Parameters.AddWithValue("@ToAccount", p_toAccount);
            cmdDeposit.Parameters.AddWithValue("@amount", p_amount);
            if (p_userType == 0)
            {
                cmdDeposit.Parameters.AddWithValue("@uType", "Admin");
            }
            else
            {
                cmdDeposit.Parameters.AddWithValue("@uType", "User");
            }

            con.Open();
          
            cmdTo.ExecuteNonQuery();
          //  cmdDeposit.ExecuteNonQuery();
            con.Close();

            return "Deposit Done";
        }
        public int GetAccountBalance(int p_accNo)
        {
           
            SqlCommand cmdGetBalance = new SqlCommand("select accBalance from AccountsInfo where accNo = @aNo", con);
            cmdGetBalance.Parameters.AddWithValue("@aNo",p_accNo);
           
            con.Open();
            SqlDataReader readRecord = cmdGetBalance.ExecuteReader();
            Account acc = new Account();
            
            if (readRecord.Read())
            {
                acc.accBalance = (int)readRecord[0];
            }
            else 
            {
                throw new Exception("Record Not Found");
            }
            readRecord.Close();
            con.Close();
            return acc.accBalance;
        }
        

    }
}

