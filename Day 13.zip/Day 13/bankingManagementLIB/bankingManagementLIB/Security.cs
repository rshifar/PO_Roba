﻿// bankingManagementLIB;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace bankingManagementLIB
{
    public enum UserType
    {
        Admin,
        Customer
    };
    public class Security
    {
        public string userName { get; set; }
        public string userPassword { get; set; } 
        SqlConnection con = new SqlConnection("server=DESKTOP-86SS27P\\ROBAINSTANCE;database=bankingManagementDB;integrated security=true");
        public string Login(string userName, string password, UserType p_uType)
        {
           
            SqlCommand cmd;
            if (p_uType == UserType.Admin)
            {
                cmd = new SqlCommand("select count(*) from AdminLogin where userName=@uName and password=@pwd", con);
            }
            else
            {
                cmd = new SqlCommand("select count(*) from userLogin where userName=@uName and password=@pwd", con);
            }

            cmd.Parameters.AddWithValue("@uName", userName);
            cmd.Parameters.AddWithValue("@pwd", password);

            con.Open();
            int loginResult = (int)cmd.ExecuteScalar();
            con.Close();

            if (p_uType == UserType.Customer)
            {
                SqlCommand cmdAttempts = new SqlCommand("select status,attempts from userLogin where userName=@uName", con);

                cmdAttempts.Parameters.AddWithValue("@uName", userName);
                con.Open();

                SqlDataReader readUser = cmdAttempts.ExecuteReader();
                if (readUser.Read())
                {
                    string status = readUser[0].ToString();
                    int attempts = (int)readUser[1];
                    readUser.Close();

                    if (status == "Blocked")
                    {
                        return "Account is Blocked, please contact Admin";
                    }
                    if (loginResult == 1 && status == "Active")
                    {
                        return "Login Successful";
                    }
                    else
                    {
                        SqlCommand updateAccount;
                        if (attempts == 3)
                        {
                            updateAccount = new SqlCommand("update userLogin set status = 'Blocked' where userName=@uName", con);
                        }
                        else
                        {
                            updateAccount = new SqlCommand("update userLogin set attempts=attempts+1 where userName=@uName", con);
                        }
                        updateAccount.Parameters.AddWithValue("@uName", userName);
                        updateAccount.ExecuteNonQuery();

                        return "Login Failed for User " + userName;
                    }

                }
                con.Close();
                return "Blank";
            }
            else
            {
                if (loginResult == 1)
                {
                    return "Login Successful For Admin";
                }
                else
                {
                    return "Login Failed For Admin";
                }
            }

        }

        private bool ChangePassword(string v_userName, string v_password)
        {
            SqlCommand cmdChagePassword = new SqlCommand("select count(*) from AdminLogin where userName=@uName and password=@pwd", con);
            cmdChagePassword.Parameters.AddWithValue("@UName", v_userName);
            cmdChagePassword.Parameters.AddWithValue("@pwd", v_password);
            con.Open();
            int v_queryResult = Convert.ToInt32(cmdChagePassword.ExecuteScalar());
            con.Close();
            if (v_queryResult == 0)
            {
                return true;
            }
              return false;
            
           }
            /*
            string current_password = userName[3];
            string confirm = Console.ReadLine();
             if (confirm == current_password)
              { 
                    
                    string password = Console.ReadLine();
                    if (password != current_password)
                    {
                        userName[3] = password;
                    }
                    else
                    {
                       ChangePassword();
                    }
                 }
                 else
                 {
                    Password mismatched
                   
                }
                try
                {
                    user_inf
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                }
                   "Your password has been changed successfully!
                
            }
                */









        }
    }
















