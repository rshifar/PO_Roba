﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Array 1
            
            int[] myNumbers = new int [5];
            myNumbers[0] = 10;
            myNumbers[1] = 20;
            myNumbers[2] = 30;
            myNumbers[3] = 40;
            myNumbers[4] = 50;
            //myNumbers[5] = 50;
            // myNumbers[5] = 60 ;//inndex out of bond exception //
            for (int i = 0; i < myNumbers.Length; i++) 
            {
                Console.WriteLine(myNumbers[i]);
            }
            
            //Console.WriteLine(myNumbers[3]);
           // for (int i = 0; i < myNumbers.Length; i++)
            //{
            //    Console.WriteLine(myNumbers[i]);
            //}
            
            #endregion

            #region Array 2
            /*
            Console.Write("How many values do you wish to store and proess \n");
            int total = Convert.ToInt32(Console.ReadLine());
            int[] myNumber = new int[total];
            for (int i = 0; i < total; i++)
            {
                Console.WriteLine("Enter Number :" +(i +1));
                myNumber[i] = Convert.ToInt32(Console.ReadLine());

            }
            int sum = 0;
            int evens = 0;
            int odd = 0;
            int negative = 0;
            for (int i = 0; i < total; i++)
            {
                sum = sum + myNumber[i];
                if (myNumber[i] % 2 == 0)
                {
                    evens = evens + 1;

                }
                else
                {
                    odd = odd + 1;
                }
                if (myNumber[i] == 0)
                {
                    negative = negative + 1;
                }
            }

            Console.WriteLine("Total of all your numbers" + sum);
            Console.WriteLine("Total even numbers" + evens);
            Console.WriteLine("Total odd your numbers" + odd);
            Console.WriteLine("Total negative your numbers" + negative);
            */
            #endregion

            
        }
    }
}