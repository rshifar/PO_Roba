﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace ado_net_part2
{
    internal class EmpInfo
    {
        SqlConnection con = new SqlConnection("server=WIN8\\NIKHILINSTANCE;database=employeeManagementDB;integrated security=true");


        #region Insert Employee and Department
        //public string AddNewEmployee()
        //{
        //    SqlCommand cmdAddNewEmployee = new SqlCommand("insert into empInfo values(21,'Mary','HR',500,1,20)", con);
        //    con.Open();
        //    cmdAddNewEmployee.ExecuteNonQuery();
        //    con.Close();
        //    return "Employee Added Successfully";
        //}

        //public string AddNewDept()
        //{
        //    SqlCommand cmdDept = new SqlCommand("insert into deptInfo values(90,'Sales','Paris','sales@rev.com')",con);
        //    con.Open();
        //    cmdDept.ExecuteNonQuery();
        //    con.Close();
        //    return "Dept Added";
        //}
        #endregion
        #region delete employee
        public string DeleteEmployee()
        {
            SqlCommand cmdDelete = new SqlCommand("delete from empInfo where empNo=21", con);
            con.Open();
            cmdDelete.ExecuteNonQuery();
            con.Close();
            return "Employee Deleted Successfully";
        }
        #endregion

    }

}