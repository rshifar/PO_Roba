create database bankingManagementDB

use bankingManagementDB
drop table userLogin
 create table userLogin
 (
 userName varchar (20),
 password varchar (20),
 status varchar (20) default 'Active',
 attemps int default (0)
 )
 insert into userLogin( userName,password) values ('Roba','password1234')
 insert into userLogin( userName,password) values ('mark','password12345')
 
 create table AdminLogin
 (
 userName varchar (20),
 password varchar (20)

 )
 insert into AdminLogin values ('AdminA','PassAdmin124')
 select * from userLogin       
 select * from AdminLogin
 drop table AccountsInfo

create table AccountsInfo
(
	accNo int primary key,
	accName varchar(20),
	accType varchar(20),        
	accBalance int,
	accStatus varchar (20) default 'Active',
	constraint chk_accType check (accType in ('Savings', 'Checking', 'Loan')),
	constraint chk_accStatus check (accStatus in ('Active', 'Disabled'))
  )

insert into AccountsInfo (accNo, accName, accType, accBalance) values ( 101,'Roba','Checking',42000)
insert into AccountsInfo (accNo, accName, accType, accBalance) values ( 102,'Mike','Checking',42000)
insert into AccountsInfo (accNo, accName, accType, accBalance) values ( 103,'Nicheal','Checking',42000)
insert into AccountsInfo (accNo, accName, accType, accBalance) values ( 104,'Sabi','Checking',42000)




drop table TransactionsInfo
create table TransactionsInfo
(
	trNo int primary key identity,
	calender datetime,
	fromAccount int,
	toAccount int,
	Amount int,
	transferedBy varchar (20),
	
	constraint fk_fromAccount foreign key (fromAccount) references AccountsInfo,
	constraint fk_toAccount foreign key (toAccount) references AccountsInfo,
)
select *from TransactionsInfo


update AccountsInfo set accBalance = accBalance- 2000 where accNo =102
update AccountsInfo set accBalance = accBalance + 2000 where accNo =104
insert into TransactionsInfo values (GETDATE(),102,104,200,'Admin')



select top 10 * from TransactionsInfo where fromAccount = 104
select * from AccountsInfo
