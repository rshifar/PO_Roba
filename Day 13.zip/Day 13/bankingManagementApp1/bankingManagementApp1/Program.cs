﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using bankingManagementLIB;
namespace bankingManagementApp1
{
    public class Program

    {
        private static bool admin = false;
        private static bool Customer = false;
        static void Main(string[] args)
        {
            // Variables and Objects
            Security secObj = new Security(); // for Admin
            Security secObj2 = new Security(); // for User
            Account accObj = new Account();
            Deposit dpObj = new Deposit();
            widraw wdObj = new widraw();
            Transactions trObj = new Transactions();
            Account newAcc = new Account();
            bool check = false;

            Console.WriteLine("~~~~ Welcome to CapitalOne Bank~~~~");
            //aske credentials check login
            Console.WriteLine("Select Login Type");
            Console.WriteLine("1. Admin");
            Console.WriteLine("2. Customer");
            Console.WriteLine("3. Exit");
            //user Type ,Password ,Admin
            int userType = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter User Name");
            string uName = Console.ReadLine();
            Console.WriteLine("Enter Password");
            string pwd = Console.ReadLine();

            if (userType == 1)
            {
               string isValidUser = secObj.Login(uName, pwd, UserType.Admin);
               if (isValidUser.Contains("Successful"))
                {
                 admin = true;
                 while (admin == true)
                 {
                   Console.BackgroundColor = ConsoleColor.Cyan;
                   Console.WriteLine("\n                                                   ");
                   Console.BackgroundColor = ConsoleColor.Black;
                   // Admin Menu
                   Console.WriteLine(" ~~~~~Welcome to CapitaOne BanK ~~~~~~~~~");
                   Console.WriteLine("------------------------------------------------------------");
                   Console.WriteLine("1.Create New Account");
                   Console.WriteLine("2.View all account  details");
                   Console.WriteLine("3.Withdraw fund");
                   Console.WriteLine("4.Deposit Fund");
                   Console.WriteLine("5.Transfar Fund");
                   Console.WriteLine("6.Disable Account");
                   Console.WriteLine("7.Exit");
                   Console.ResetColor();
                   Console.WriteLine("Enter your choice:");
                   int choice = Convert.ToInt32(Console.ReadLine());
                   switch (choice)
                    {
                    case 1:
                       Console.WriteLine("Enter Account Number");
                       int v_accNo = Convert.ToInt32(Console.ReadLine());
                       Console.WriteLine("Enter Account  Name");
                       string v_accName = Console.ReadLine();
                       Console.WriteLine("Enter Account Balance");
                       int v_accBalance = Convert.ToInt32(Console.ReadLine());
                       Console.WriteLine("Enter Account Type ");
                       string v_accType = Console.ReadLine();
                       string result = accObj.AddAccount(v_accNo, v_accName, v_accType, v_accBalance);
                       Console.WriteLine(result);
                       break;

                    case 2:// View Account details(All)
                       List<Account> accList = accObj.GetAllAccountInfo();
                       int totalAcc = 0;
                       foreach (var item in accList)
                       {
                       Console.WriteLine("Account Number  : "   +   item.accNo);
                       Console.WriteLine("Account Name    : "   +   item.accName);
                       Console.WriteLine("Account Balance : "   +   item.accBalance);
                       Console.WriteLine("Account Type    : "   +   item.accType);
                       Console.WriteLine("_______________________________________________________________");
                       Console.WriteLine();
                       totalAcc = totalAcc + 1;
                       }
                       Console.WriteLine("Total Account: "  +  totalAcc);
                       break;
                    case 3:  //Perform widraw
                        Console.WriteLine("Enter  Account Number ");
                       //int v_Amountwd = Convert.ToInt32(Console.ReadLine());
                        int V_fromAcc = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Amount to widraw ");
                        int v_Amountwd = Convert.ToInt32(Console.ReadLine());
                        string widrawResult = wdObj.Widraw(V_fromAcc, v_Amountwd, UserType.Admin);
                        Console.WriteLine(widrawResult);
                        break;
                    case 4:     //Perform deposit
                         Console.WriteLine("Enter Amount to Deposit ");
                         int v_AmountDp = Convert.ToInt32(Console.ReadLine());
                         Console.WriteLine("Enter to Account Number ");
                         int var_fromAcc = Convert.ToInt32(Console.ReadLine());
                         string depositResult = dpObj.GetDeposit(var_fromAcc, v_AmountDp, UserType.Admin);
                         Console.WriteLine(depositResult);
                         break;
                    case 5://Transfer funds
                         Console.WriteLine("Enter account number to transfer funds:");
                         Console.WriteLine("Enter From Account Number ");
                         int v_fromAcc = Convert.ToInt32(Console.ReadLine());
                         Console.WriteLine("Enter To Account Number ");
                         int v_ToAcc = Convert.ToInt32(Console.ReadLine());
                         Console.WriteLine("Enter Amount To Transfer ");
                         int v_Amount = Convert.ToInt32(Console.ReadLine());
                         string transferResult = trObj.Transfer(v_fromAcc, v_ToAcc, v_Amount, UserType.Admin);
                         Console.WriteLine(transferResult);
                         break;
                    case 6: // Disable an account 
                          Console.WriteLine("Enter Account Number ");
                          v_accNo = Convert.ToInt32(Console.ReadLine());
                          string disableResult = accObj.DisableAccount(v_accNo);
                          Console.WriteLine(disableResult);
                          break;
                    case 7://Exit
                          Environment.Exit(0);
                          break;
                    default:
                           Console.Clear();
                           break;
                     }

                     }
                      }
                      else
                      {
                       Console.WriteLine(isValidUser);
                      }
                         }
                        else
                         {
                              string isValidUser = secObj2.Login(uName, pwd, UserType.Customer);
                              if (isValidUser.Contains("Successful"))
                              {
                                   Customer = true;
                                   while (Customer = true) // User Menu
                                   {
                                     Console.BackgroundColor = ConsoleColor.Red;
                                     Console.WriteLine("\n                                                   ");
                                     Console.BackgroundColor = ConsoleColor.Black;
                                    //Console.Clear();
                                     Console.WriteLine("Welcome to CapitaOne Bank");
                                     Console.WriteLine("What would you like to do next");
                                     Console.WriteLine("1.Check your Balance");
                                     Console.WriteLine("2.Withdrawal");
                                     Console.WriteLine("3.Deposit Funds");
                                     Console.WriteLine("4.Transfar Fund");
                                     Console.WriteLine("5.View List 10 Transactions");
                                     Console.WriteLine("6.Exit");
                                     Console.WriteLine("Choose One (1-6)");
                                    //Console.WriteLine("Enter your choice:");
                                     int choice1 = Convert.ToInt32(Console.ReadLine());
                                     switch (choice1)
                                     {
                                       case 1:
                                          string v_accName = uName;
                                          int v_balance = accObj.GetAccountBalance(v_accName);
                                          Console.WriteLine("Current balance: $" + v_balance);
                                          break;
                                       case 2:
                                           Console.WriteLine("Enter  Account Number ");
                                           //int v_Amountwd = Convert.ToInt32(Console.ReadLine());
                                           int V_fromAcc = Convert.ToInt32(Console.ReadLine());
                                           Console.WriteLine("Enter Amount to Withdrawal ");
                                           int v_Amountwd = Convert.ToInt32(Console.ReadLine());
                                           string widrawResult = wdObj.Widraw(V_fromAcc, v_Amountwd, UserType.Customer);
                                           Console.WriteLine(widrawResult);
                                           break;
                                       case 3:
                                            Console.WriteLine("Enter Amount to Deposit ");
                                            int v_AmountDp = Convert.ToInt32(Console.ReadLine());
                                            Console.WriteLine("Enter to Account Number ");
                                            int var_fromAcc = Convert.ToInt32(Console.ReadLine());
                                            string depositResult = dpObj.GetDeposit(var_fromAcc, v_AmountDp, UserType.Customer);
                                            Console.WriteLine(depositResult);
                                            break;
                                       case 4:
                                           Console.WriteLine("Enter account number to transfer funds:");
                                           Console.WriteLine("Enter From Account Number ");
                                           int v_fromAcc = Convert.ToInt32(Console.ReadLine());
                                           Console.WriteLine("Enter To Account Number ");
                                           int v_ToAcc = Convert.ToInt32(Console.ReadLine());
                                           Console.WriteLine("Enter Amount To Transfer ");
                                           int v_Amount = Convert.ToInt32(Console.ReadLine());
                                           string transferResult = trObj.Transfer(v_fromAcc, v_ToAcc, v_Amount, UserType.Customer);
                                           Console.WriteLine(transferResult);
                                           break;
                                      case 5:
                                           Console.WriteLine("Enter Account Number ");
                                           int v_fromAcc2 = Convert.ToInt32(Console.ReadLine());
                                           List<Transactions> tranList = trObj.GetTransactionsInfo(v_fromAcc2);
                                           int totalAcc = 0;
                                          Console.WriteLine(" Transaction  Number \t\t Account Date\t\t fromAccount \t\t toAccount \t\taccAmount") ;
                                           foreach (var item in tranList)
                                           {
                                           Console.WriteLine(item.trNo + "\t\t" + item.accDate +"\t\t" +  item.accAmount + "\t\t" + item.fromAccount + "\t\t"  + item.toAccount);
                                           Console.WriteLine("_______________________________________________________________");
                                           Console.WriteLine();
                                           totalAcc = totalAcc + 1;
                                           }
                                           Console.WriteLine("Total Account :  " + totalAcc);
                                          break;
                                      case 6:
                                          Console.WriteLine("Thank you for Banking with us .....Come again");
                                          Console.WriteLine("Click  Exit to Complite Application ");
                                           return;
                                      default:
                                           Console.Clear();
                                           break;
                                    }
                                    }
                                    }
                                   else
                                   {
                                   Console.WriteLine(isValidUser);
                                   }
                                  }





        }


    }
}


            
        
    


    






                
        

    

